package com.example.galwaytourismapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button aboutGalwayButtonJ, drinkButtonJ,placesToSeeButtonJ,foodButtonJ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        aboutGalwayButtonJ = findViewById(R.id.aboutGalwayButton);
        aboutGalwayButtonJ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tripadvisor.ie/Tourism-g186609-Galway_County_Galway_Western_Ireland-Vacations.html"));
                startActivity(browserIntent);

            }
        });

        drinkButtonJ = findViewById(R.id.drinkButton);
        drinkButtonJ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://thisisgalway.ie/drink/"));
                startActivity(browserIntent);
            }
        });

        placesToSeeButtonJ = findViewById(R.id.placesToSeeButton);
        placesToSeeButtonJ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, PlacesToSeeActivity.class));
    
            }
        });

        foodButtonJ = findViewById(R.id.foodButton);
        foodButtonJ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, FoodActivity.class));

            }
        });
    }
}