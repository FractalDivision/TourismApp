package com.example.galwaytourismapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class AboutGalwayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_galway);


        startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse("https://www.tripadvisor.ie/Tourism-g186609-Galway_County_Galway_Western_Ireland-Vacations.html")));


    }
}